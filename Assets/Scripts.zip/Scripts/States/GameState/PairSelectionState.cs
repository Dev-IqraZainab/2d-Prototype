using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PairSelectionState : GameState
{
	public PairSelectionState(GameManager gameManager) : base(gameManager)
	{
	}

	public override void UpdateAction()
	{
		return;
	}
}
