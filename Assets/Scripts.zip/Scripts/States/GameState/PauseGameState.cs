using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseGameState : GameState
{
	public PauseGameState(GameManager gameManager) : base(gameManager)
	{
	}

	public override void UpdateAction()
	{
		throw new System.NotImplementedException();
	}
}
