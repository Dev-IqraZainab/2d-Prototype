using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardSelectionState : GameState
{
	public CardSelectionState(GameManager gameManager) : base(gameManager)
	{
	}

	public override void UpdateAction()
	{
		return;
	}
}
